# Loopweek Flutter REA example

This example records REA inspection of the published Android release for [ZaryabKhan/Loopweek](https://github.com/ZaryabKhan/Loopweek), pinned to tag `v1.0.3` and source commit `f07a75f0875c2b51a953c258c358fbfca957be89`. GitHub reports the repository as MIT-licensed and the project includes its [`LICENSE`](https://github.com/ZaryabKhan/Loopweek/blob/main/LICENSE). The release publishes [`Loopweek-v1.0.3.apk`](https://github.com/ZaryabKhan/Loopweek/releases/tag/v1.0.3) with SHA-256 `ac8e37299f2d62af5314c5f9953a3febda35ad66fb33c40e358ca01d8327c71a`. The APK is kept outside this repo; no app binary or build output is vendored.

## REA result

Pinned REA 6.8.0 identified Flutter payloads in all three APK ABIs. Its `arm64-v8a` `libapp.so` AOT snapshot is 6,947,728 bytes (`024e583f56aa82d132410a7d2a0eb66349b2aa1cc22f2e82ff7dd87b43156515`) with snapshot hash `ace654289f5abc240509fc941453ebc5`. REA's AOT inspector reported complete coverage of the four AOT snapshot sections and found 4 Dart snapshot sections.

The string-pool projection is partial: it retained 500 package URIs out of at least 682, 195 Dart URIs, and 2000 class-like tokens out of at least 4000. The analyzer documents that these strings are byte-pattern observations; they are not deserialized Dart classes or recovered methods. See the detailed limitations in the [hash-bound REA report](evidence/inspect-dart-aot-arm64-001.json). The separate [Flutter build identification report](evidence/identify-flutter-build-001.json) records the three ABI payload hashes and coverage.

The pinned Android package inspection report is [available here](evidence/inspect-android-package-001.json); it records JADX metadata for package `com.appcodecraft.loopweek` version `1.0.3`. It is static decompiler output, does not establish runtime behavior, and did not verify the APK signature.

## Emulator behavior check

On one Android 16/API 36 arm64 emulator, the published APK was installed, a task named `Anti-REA behavior check` was created and marked complete, then the app was force-stopped and relaunched. The task remained visible and checked afterward. The structured [behavior evidence](evidence-summary.json) records the APK digest and the external screenshot digest; the screenshot itself is kept outside this repository.

This single journey is limited behavior evidence, not broad app coverage. No transformation candidate or BEFORE/AFTER comparison was run, and this example makes no protection claim.
