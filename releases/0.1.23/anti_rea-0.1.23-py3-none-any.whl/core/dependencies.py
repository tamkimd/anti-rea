"""Prepare only the pinned upstream runtimes selected for a workflow."""
from __future__ import annotations

import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import sysconfig

from core import workflow
from core import upstream_review

ROOT = Path(__file__).resolve().parents[1]
_RUNTIME_ENV = {"bla": "ANTI_REA_BLA_RUNTIME", "e2e": "ANTI_REA_E2E_RUNTIME",
                "rea": "ANTI_REA_REA_RUNTIME"}
_PROJECT_LOCK_LIMIT = 32 * 1024 * 1024


def _upstreams_path() -> Path:
    path = ROOT / "locks/upstreams.json"
    if path.is_file():
        return path
    path = Path(sysconfig.get_path("data")) / "share/anti-rea/locks/upstreams.json"
    if not path.is_file():
        raise workflow.WorkflowError("Packaged upstream lock file is unavailable")
    return path


def _node_identity(engine: str, adapter):
    checker = adapter.runner if engine == "bla" else adapter
    version, parts = checker.node_version()
    supported = (adapter.supported_node(parts) if engine in {"bla", "rea"}
                 else ((parts[0] == 22 and parts >= (22, 22, 3)) or
                       (parts[0] >= 24 and parts >= (24, 8, 0)))
                 if engine == "e2e" else False)
    if not supported:
        raise workflow.WorkflowError(f"Pinned {engine} runtime does not support Node {version}")
    return version


def _private_directory(path: Path) -> Path:
    if path.is_symlink():
        raise workflow.WorkflowError("Dependency cache directories cannot be symlinks")
    if not path.exists():
        path.mkdir(mode=0o700, parents=True)
    if not path.is_dir():
        raise workflow.WorkflowError("Dependency cache path must be a directory")
    if os.name != "nt":
        info = path.stat()
        if info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise workflow.WorkflowError("Dependency cache directories must be private and owned by the current user")
    return path


def _runtime_identity(engine: str, adapter, runtime: Path, node_version: str):
    try:
        runtime, manifest = adapter.verify_runtime(runtime)
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} runtime verification failed: {error}") from error
    if manifest.get("node_version") != node_version:
        raise workflow.WorkflowError("Pinned runtime was prepared with a different Node version")
    return runtime, manifest


def _lock_selectors(header: str) -> list[str]:
    return [next(value for value in match if value).strip().strip("\"'")
            for match in re.findall(r'"([^\"]+)"|\'([^\']+)\'|([^,]+)', header)]


def _selector_package(selector: str) -> str:
    return selector.rpartition("@")[0].lstrip("/")


def _collapse_lock_entries(entries: dict[str, list[dict]]) -> dict[str, dict]:
    result = {}
    for name, identities in entries.items():
        distinct = {(item.get("version"), item.get("integrity")) for item in identities}
        if len(distinct) == 1:
            version, integrity = next(iter(distinct))
            result[name] = {"version": version, "integrity": integrity}
        else:
            result[name] = {"version": None, "integrity": None}
    return result


def _yarn_classic_lock_entries(raw: bytes, packages: dict) -> dict[str, dict] | None:
    """Read direct identities from Yarn Classic lockfiles only."""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return None
    if "__metadata:" in text or not text.strip():
        return None
    entries: dict[str, list[dict]] = {}
    lines = text.splitlines()
    index = 0
    while index < len(lines):
        line = lines[index]
        if not line or line[0].isspace() or line.startswith("#") or not line.endswith(":"):
            index += 1
            continue
        selectors = {_selector_package(item) for item in _lock_selectors(line[:-1])}
        block = []
        index += 1
        while index < len(lines) and (not lines[index] or lines[index][0].isspace()):
            block.append(lines[index])
            index += 1
        versions = re.findall(r'^\s+version\s+["\']?([^\s"\']+)', "\n".join(block), re.MULTILINE)
        integrities = re.findall(r'^\s+integrity\s*:?[ \t]+([^\s"\']+)', "\n".join(block), re.MULTILINE)
        if len(set(versions)) == 1 and len(set(integrities)) == 1:
            identity = {"version": versions[0], "integrity": integrities[0]}
            for name in packages.keys() & selectors:
                entries.setdefault(name, []).append(identity)
    return _collapse_lock_entries(entries) if entries else None


def _pnpm_v9_lock_entries(raw: bytes, packages: dict) -> dict[str, dict] | None:
    """Read direct package identities from pnpm's v9 packages map."""
    try:
        lines = raw.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return None
    if not any(re.fullmatch(r"lockfileVersion:\s*['\"]?9(?:\.0)?['\"]?", line) for line in lines):
        return None
    entries: dict[str, list[dict]] = {}
    in_packages = False
    index = 0
    while index < len(lines):
        line = lines[index]
        if line == "packages:":
            in_packages = True
            index += 1
            continue
        if line and not line[0].isspace():
            in_packages = False
        if not in_packages or not re.match(r"^  [^ ].*:\s*$", line):
            index += 1
            continue
        key = line.strip()[:-1].strip().strip("\"'")
        name = _selector_package(key.split("(", 1)[0])
        block = []
        index += 1
        while index < len(lines) and (not lines[index] or lines[index].startswith("    ")):
            block.append(lines[index])
            index += 1
        versions = re.findall(r"(?:^|@)(\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?)", key)
        identities = re.findall(r"integrity:\s*['\"]?([^\s,'\"}]+)", "\n".join(block))
        if (name in packages and len(set(versions)) == 1 and len(set(identities)) == 1):
            entries.setdefault(name, []).append({"version": versions[0], "integrity": identities[0]})
    return _collapse_lock_entries(entries) if entries else None


def _project_dependency_report(engine: str, project: Path, pin: dict) -> dict:
    """Report project-local package matches without treating them as trusted runtimes."""
    packages = (pin.get("packages") if engine == "e2e" else
                {pin["npm_package"]: {"version": pin["npm_version"], "integrity": pin["npm_integrity"]}})
    result = {"status": "not_detected", "lockfile": None, "lockfile_manager": None,
              "packages": {}, "lockfile_matches_pin": None, "reusable": False,
              "reason": "project package metadata is unavailable"}
    try:
        try:
            manifest = json.loads(upstream_review._read_lock(project, Path("package.json"), "Project package manifest"))
        except workflow.WorkflowError:
            manifest = {}
        lockfile = None
        lock = None
        for filename, manager in (("package-lock.json", "npm"), ("npm-shrinkwrap.json", "npm"),
                                  ("pnpm-lock.yaml", "pnpm"), ("yarn.lock", "yarn")):
            candidate = project / filename
            if not candidate.exists() and not candidate.is_symlink():
                continue
            raw_lock = upstream_review._read_lock(project, Path(filename), "Project package lock")
            if len(raw_lock) > _PROJECT_LOCK_LIMIT:
                raise workflow.WorkflowError("Project package lock exceeds the size budget")
            lockfile, result["lockfile_manager"] = filename, manager
            if manager == "npm":
                lock = json.loads(raw_lock)
            break
        result["lockfile"] = lockfile
        entries = None
        lockfile_v1 = False
        if isinstance(lock, dict):
            version = lock.get("lockfileVersion")
            if version in {2, 3} and isinstance(lock.get("packages"), dict):
                entries = lock["packages"]
            elif version == 1 and isinstance(lock.get("dependencies"), dict):
                entries = lock["dependencies"]
                lockfile_v1 = True
        elif result["lockfile_manager"] == "yarn":
            entries = _yarn_classic_lock_entries(raw_lock, packages)
        elif result["lockfile_manager"] == "pnpm":
            entries = _pnpm_v9_lock_entries(raw_lock, packages)
        declarations = {}
        if isinstance(manifest, dict):
            for section in ("dependencies", "devDependencies", "optionalDependencies"):
                if isinstance(manifest.get(section), dict):
                    declarations.update({name: section for name in packages if name in manifest[section]})
        for name, expected in packages.items():
            locked = (entries.get(f"node_modules/{name}") if entries is not None and not lockfile_v1
                      and result["lockfile_manager"] == "npm" else
                      entries.get(name) if entries is not None else None)
            installed = None
            try:
                installed = json.loads(upstream_review._read_lock(
                    project, Path("node_modules") / name / "package.json", f"Installed {name} manifest"))
            except workflow.WorkflowError:
                pass
            locked_match = (isinstance(locked, dict) and locked.get("version") == expected.get("version")
                            and locked.get("integrity") == expected.get("integrity")) if entries is not None else None
            installed_match = (isinstance(installed, dict) and installed.get("name") == name
                               and installed.get("version") == expected.get("version"))
            result["packages"][name] = {"declared_in": declarations.get(name),
                                        "locked": bool(locked), "lock_matches_pin": locked_match,
                                        "installed": installed is not None,
                                        "installed_version_matches_pin": installed_match}
        result["lockfile_matches_pin"] = (all(item["lock_matches_pin"] for item in result["packages"].values())
                                           if entries is not None else None)
        all_installed = all(item["installed"] for item in result["packages"].values())
        all_versions = all(item["installed_version_matches_pin"] for item in result["packages"].values())
        result["status"] = (
            "pinned_metadata_match" if all_installed and all_versions and result["lockfile_matches_pin"] is True
            else "mismatch" if all_installed and entries is not None
            else "installed_unverified" if all_installed
            else "partial" if any(item["installed"] for item in result["packages"].values())
            else "not_installed" if lockfile else "not_detected")
        result["reason"] = (
            "installed bytes have no authenticated Anti-REA runtime identity"
            if result["status"] == "pinned_metadata_match"
            else "project lockfile format is detected but its package identity is not verified"
            if result["status"] == "installed_unverified"
            else "project dependencies do not fully match the pinned package set")
        return result
    except (workflow.WorkflowError, UnicodeDecodeError, json.JSONDecodeError):
        return {**result, "status": "unavailable",
                "reason": "project npm lock is missing, unsupported, or could not be safely read"}


def inspect_project_dependencies(engine: str, project: str | Path) -> dict:
    """Read project npm metadata without preparing or executing a runtime."""
    if engine not in _RUNTIME_ENV:
        raise workflow.WorkflowError("Unknown upstream engine")
    project_root = Path(project).expanduser().resolve(strict=True)
    if not project_root.is_dir():
        raise workflow.WorkflowError("Project root must be a directory")
    pin = json.loads(_upstreams_path().read_text())["integrations"][engine]
    return {"status": "inspected", "engine": engine,
            "project_dependencies": _project_dependency_report(engine, project_root, pin),
            "limitations": ["Project metadata matches do not authenticate installed package bytes; no dependency is reused by this inspection."]}


def prepare(engine: str, project: str | Path, cache: str | Path | None, adapter,
            runtime: str | Path | None = None, offline: bool = False) -> dict:
    """Verify an explicit runtime or prepare/reuse an isolated pinned cache entry."""
    if engine not in _RUNTIME_ENV:
        raise workflow.WorkflowError("Unknown upstream engine")
    if not isinstance(offline, bool):
        raise workflow.WorkflowError("Offline mode must be boolean")
    project_root = Path(project).expanduser().resolve(strict=True)
    if not project_root.is_dir():
        raise workflow.WorkflowError("Project root must be a directory")
    pin = json.loads(_upstreams_path().read_text())["integrations"][engine]
    project_dependencies = _project_dependency_report(engine, project_root, pin)
    try:
        node_version = _node_identity(engine, adapter)
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} Node runtime is unavailable: {error}") from error
    configured = runtime or os.environ.get(_RUNTIME_ENV[engine])
    if configured:
        selected = Path(configured).expanduser()
        if selected.is_symlink():
            raise workflow.WorkflowError("Configured runtime cannot be a symlink")
        selected, manifest = _runtime_identity(engine, adapter, selected, node_version)
        return _result(engine, pin, selected, manifest, node_version,
                       manifest.get("npm_version_runtime"), "verified", "explicit", project_dependencies)

    if cache is None:
        raise workflow.WorkflowError("Pass --cache-dir when no verified runtime was supplied")
    try:
        npm_version = subprocess.run(["npm", "--version"], check=True, capture_output=True,
                                     text=True, timeout=10).stdout.strip()
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} npm runtime is unavailable: {error}") from error

    cache_root = Path(cache).expanduser().absolute()
    if cache_root.is_symlink():
        raise workflow.WorkflowError("Dependency cache cannot be a symlink")
    canonical_cache = cache_root.resolve(strict=False)
    if canonical_cache == project_root or project_root in canonical_cache.parents:
        raise workflow.WorkflowError("Dependency cache must be outside the project")
    if offline and not canonical_cache.is_dir():
        raise workflow.WorkflowError("Offline dependency cache miss; prepare this pinned runtime while online")
    _private_directory(canonical_cache)
    node_key = re.sub(r"[^a-zA-Z0-9._-]", "_", node_version)
    npm_key = re.sub(r"[^a-zA-Z0-9._-]", "_", npm_version)
    platform_key = f"{sys.platform}-{platform.machine().lower()}"
    entry = canonical_cache / engine / f"{pin.get('npm_version', 'multi')}-{platform_key}-node-{node_key}-npm-{npm_key}"
    if entry.exists() or entry.is_symlink():
        if entry.is_symlink():
            raise workflow.WorkflowError("Cached runtime cannot be a symlink")
        selected, manifest = _runtime_identity(engine, adapter, entry, node_version)
        return _result(engine, pin, selected, manifest, node_version, npm_version, "reused", "cache", project_dependencies)
    if offline:
        raise workflow.WorkflowError("Offline dependency cache miss; prepare this pinned runtime while online")
    _private_directory(entry.parent)
    try:
        adapter.bootstrap(entry)
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} runtime preparation failed: {error}") from error
    selected, manifest = _runtime_identity(engine, adapter, entry, node_version)
    return _result(engine, pin, selected, manifest, node_version, npm_version, "prepared", "cache", project_dependencies)


def _result(engine: str, pin: dict, runtime: Path, manifest: dict, node_version: str,
            npm_version: str, status: str, source: str, project_dependencies: dict | None = None) -> dict:
    packages = ({"e2e": pin["packages"]} if engine == "e2e" else
                {pin["npm_package"]: {"version": pin["npm_version"], "integrity": pin["npm_integrity"]}})
    tree_hash = manifest.get("package_tree_sha256")
    return {"status": status, "engine": engine, "runtime": str(runtime), "source": source,
            "packages": packages, "license": pin["license"], "node_requirement": pin["node_requirement"],
            "node_version": node_version, "npm_version": npm_version,
            "package_lock_sha256": pin["package_lock_sha256"],
            "package_tree_sha256": tree_hash,
            "project_dependencies": project_dependencies or {"status": "not_checked", "reusable": False},
            "install_scripts": manifest.get("install_scripts", "disabled"),
            "limitations": ["Only the exact pinned runtime is reused; engine applicability and successful operation require separate checks.",
                            "The cache is isolated from the project and does not install global or project dependencies."]}
