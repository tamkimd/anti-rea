"""Small command planner for an explicitly selected Flutter Android release build."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

from core import baseline, workflow

_ANDROID_SECTION = re.compile(r"^\[(✓|!|✗)\] Android toolchain(?:\s|$)(.*)$", re.MULTILINE)
_ANDROID_SDK_MISSING = re.compile(r"android sdk (?:was )?not found|unable to locate (?:the )?android sdk", re.I)
_ANDROID_LICENSES_MISSING = re.compile(r"android licenses? (?:are )?not accepted|licenses? not accepted", re.I)


def build_command(project: str | Path, target: str, split_debug_info: str | Path,
                  flutter: str = "flutter") -> list[str]:
    """Return Flutter's release obfuscation command for an Android project."""
    root = Path(project).expanduser().resolve(strict=True)
    if not root.is_dir() or not (root / "pubspec.yaml").is_file() or not (root / "android").is_dir():
        raise workflow.WorkflowError("Flutter Android project requires pubspec.yaml and android/ at its root")
    if target not in {"apk", "appbundle"}:
        raise workflow.WorkflowError("Flutter Android target must be apk or appbundle")
    debug_info = Path(split_debug_info).expanduser().resolve()
    if debug_info == root or root in debug_info.parents:
        raise workflow.WorkflowError("Split debug information must be stored outside the project")
    executable = shutil.which(flutter)
    if executable is None:
        raise workflow.WorkflowError(f"Flutter executable is unavailable: {flutter}")
    return [executable, "build", target, "--release", "--obfuscate",
            f"--split-debug-info={debug_info}"]


def probe_android_environment(flutter: str = "flutter", timeout_seconds: float = 120) -> dict:
    """Report Flutter, Android SDK/license, and device readiness without accepting or installing anything."""
    if (isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float))
            or not 0 < timeout_seconds <= 600):
        raise workflow.WorkflowError("Flutter probe timeout must be greater than 0 and at most 600 seconds")
    if not isinstance(flutter, str) or not flutter.strip():
        raise workflow.WorkflowError("Flutter executable must be a non-empty path or command")
    executable = shutil.which(flutter)
    if executable is None:
        return _probe_result(flutter, None, [], "unavailable", None, "unknown", "unknown")

    commands = []

    def run(args, limit):
        argv = [executable, *args]
        try:
            code, stdout, stderr, timed_out, stdout_truncated, stderr_truncated = baseline._run_command(
                argv, Path.cwd(), min(float(timeout_seconds), limit), total_output_limit=1024 * 1024)
        except OSError as error:
            return {"argv": argv, "status": "failed", "error": str(error)}
        record = {"argv": argv, "exit_code": code,
                  "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
                  "stderr_sha256": hashlib.sha256(stderr).hexdigest(),
                  "stdout": stdout.decode("utf-8", errors="replace"),
                  "stderr": stderr.decode("utf-8", errors="replace"),
                  "status": "timed_out" if timed_out else "output_limit" if stdout_truncated or stderr_truncated
                  else "completed" if code == 0 else "failed"}
        commands.append(record)
        return record

    version_result = run(["--version", "--machine"], 30)
    version_data = None
    if version_result["status"] == "completed":
        try:
            value = json.loads(version_result["stdout"])
            if (isinstance(value, dict) and isinstance(value.get("frameworkVersion"), str)
                    and value["frameworkVersion"] and isinstance(value.get("channel"), str)
                    and value["channel"]):
                version_data = {key: value[key] for key in
                                ("frameworkVersion", "channel", "frameworkRevision", "engineRevision", "dartSdkVersion")
                                if isinstance(value.get(key), str)}
        except json.JSONDecodeError:
            pass
    if version_data is None:
        return _probe_result(flutter, executable, commands, "incomplete", None, "unknown", "unknown")

    doctor = run(["doctor", "--suppress-analytics"], 180)
    doctor_text = doctor.get("stdout", "") + "\n" + doctor.get("stderr", "")
    match = _ANDROID_SECTION.search(doctor_text)
    if not match:
        sdk_status, license_status = "unknown", "unknown"
    else:
        mark, detail = match.groups()
        start, end = match.span()
        next_section = re.search(r"^\[[✓!✗]\] ", doctor_text[end:], re.MULTILINE)
        section = detail + (doctor_text[end:end + next_section.start()] if next_section else doctor_text[end:])
        if _ANDROID_SDK_MISSING.search(section):
            sdk_status, license_status = "blocked", "unknown"
        elif mark == "✓":
            sdk_status, license_status = "ready", "accepted"
        elif _ANDROID_LICENSES_MISSING.search(section):
            sdk_status, license_status = "ready", "not_accepted"
        else:
            sdk_status, license_status = "incomplete", "unknown"
    if doctor["status"] in {"timed_out", "output_limit", "failed"}:
        if sdk_status == "ready":
            sdk_status = "incomplete"
        if license_status == "accepted":
            license_status = "unknown"

    devices_result = run(["devices", "--machine", "--suppress-analytics"], 60)
    devices = None
    if devices_result["status"] == "completed":
        try:
            value = json.loads(devices_result["stdout"])
            if isinstance(value, list) and all(isinstance(item, dict) for item in value):
                android = [item for item in value if isinstance(item.get("targetPlatform"), str)
                           and item["targetPlatform"].startswith("android") and item.get("isSupported") is True]
                devices = {"status": "available" if android else "none_connected",
                           "count": len(android),
                           "emulator_count": sum(item.get("emulator") is True for item in android),
                           "physical_count": sum(item.get("emulator") is False for item in android)}
        except json.JSONDecodeError:
            pass
    devices_result.pop("stdout", None)  # Device IDs can contain stable, user-specific hardware identifiers.
    if devices is None:
        devices = {"status": "unknown", "count": None, "emulator_count": None, "physical_count": None}

    build_status = "ready" if sdk_status == "ready" and license_status == "accepted" else (
        "blocked" if "blocked" in {sdk_status, license_status} or license_status == "not_accepted" else "incomplete")
    device_status = "ready" if devices["status"] == "available" else (
        "blocked" if devices["status"] == "none_connected" else "incomplete")
    status = "ready" if build_status == "ready" and device_status == "ready" else (
        "blocked" if "blocked" in {build_status, device_status} else "incomplete")
    return {"status": status, "scope": "flutter_android_toolchain_only",
            "flutter": {"executable": str(Path(executable).resolve()), **version_data},
            "checks": {"android_sdk": sdk_status, "android_licenses": license_status,
                       "android_build": build_status, "android_device": devices},
            "commands": commands,
            "limitations": ["Does not build, sign, install, or run an application.",
                            "Does not accept Android licenses or install toolchains.",
                            "Toolchain readiness does not establish app compatibility."]}


def _probe_result(flutter: str, executable: str | None, commands: list[dict], status: str,
                  version: dict | None, sdk_status: str, license_status: str) -> dict:
    return {"status": status, "scope": "flutter_android_toolchain_only",
            "flutter": ({"executable": str(Path(executable).resolve()), **version} if executable and version else None),
            "requested_flutter": flutter,
            "checks": {"android_sdk": sdk_status, "android_licenses": license_status,
                       "android_build": "incomplete", "android_device": {"status": "unknown", "count": None,
                                                                              "emulator_count": None,
                                                                              "physical_count": None}},
            "commands": commands,
            "limitations": ["Does not build, sign, install, or run an application.",
                            "Does not accept Android licenses or install toolchains.",
                            "Toolchain readiness does not establish app compatibility."]}
