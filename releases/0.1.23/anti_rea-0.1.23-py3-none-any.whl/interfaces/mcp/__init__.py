"""MCP server interface."""
