"""Anti-REA integration interfaces."""
