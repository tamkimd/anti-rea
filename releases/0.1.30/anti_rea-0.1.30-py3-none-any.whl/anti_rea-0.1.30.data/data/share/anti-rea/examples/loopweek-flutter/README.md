# Loopweek Flutter REA example

This example records REA inspection of the published Android release for [ZaryabKhan/Loopweek](https://github.com/ZaryabKhan/Loopweek), pinned to tag `v1.0.3` and source commit `f07a75f0875c2b51a953c258c358fbfca957be89`. GitHub reports the repository as MIT-licensed and the project includes its [`LICENSE`](https://github.com/ZaryabKhan/Loopweek/blob/main/LICENSE). The release publishes [`Loopweek-v1.0.3.apk`](https://github.com/ZaryabKhan/Loopweek/releases/tag/v1.0.3) with SHA-256 `ac8e37299f2d62af5314c5f9953a3febda35ad66fb33c40e358ca01d8327c71a`. The APK is kept outside this repo; no app binary or build output is vendored.

## REA result

Pinned REA 6.8.0 identified Flutter payloads in all three APK ABIs. Its `arm64-v8a` `libapp.so` AOT snapshot is 6,947,728 bytes (`024e583f56aa82d132410a7d2a0eb66349b2aa1cc22f2e82ff7dd87b43156515`) with snapshot hash `ace654289f5abc240509fc941453ebc5`. REA's AOT inspector reported complete coverage of the four AOT snapshot sections and found 4 Dart snapshot sections.

The string-pool projection is partial: it retained 500 package URIs out of at least 682, 195 Dart URIs, and 2000 class-like tokens out of at least 4000. The analyzer documents that these strings are byte-pattern observations; they are not deserialized Dart classes or recovered methods. See the detailed limitations in the [hash-bound REA report](evidence/inspect-dart-aot-arm64-001.json). The separate [Flutter build identification report](evidence/identify-flutter-build-001.json) records the three ABI payload hashes and coverage.

The pinned Android package inspection report is [available here](evidence/inspect-android-package-001.json); it records JADX metadata for package `com.appcodecraft.loopweek` version `1.0.3`. It is static decompiler output, does not establish runtime behavior, and did not verify the APK signature.

The separate [APK signature verification report](evidence/apk-signature-verification-001.json) records Android `apksigner` returning `Verifies` for the pinned APK digest with v2 signature scheme and one RSA-2048 signer. This establishes cryptographic validity under the embedded certificate. The certificate identity was not checked against an external publisher trust anchor.

## Emulator behavior check

On one Android 16/API 36 arm64 emulator, the published APK was installed, a task named `Anti-REA behavior check` was created and marked complete, then the app was force-stopped and relaunched. The task remained visible and checked afterward. The structured [behavior evidence](evidence-summary.json) records the APK digest and the external screenshot digest; the screenshot itself is kept outside this repository.

This single journey is limited behavior evidence, not broad app coverage. No transformation candidate or BEFORE/AFTER comparison was run, and this example makes no protection claim.

## Fresh Anti-REA baseline build

Anti-REA 0.1.29 also built the pinned source commit `f07a75f0875c2b51a953c258c358fbfca957be89` privately with Flutter 3.47.8. The 94.6-second APK build produced a 62,349,581-byte artifact with SHA-256 `9389f711fd6566c0906a38d137d1221801dbcb7e90db26b727aee04b3987b18b`; the APK and build tree remain outside this repository. The hash-bound [baseline summary](evidence/local-anti-rea-baseline-001.json) links the detailed REA reports and tool identities.

REA 6.8.0 identified Flutter payloads in all three ABIs, with overall partial coverage. Its AOT inspector could not analyze this build: it observed unified Dart snapshot exports, while the pinned reader supports the legacy Dart 2.14 split VM/isolate profile. The [blocked inspection result](evidence/rea-inspect-dart-aot-local-baseline-001.json) records that limitation. Android package inspection was also blocked because no JADX provider was configured ([result](evidence/rea-inspect-android-package-local-baseline-001.json)).

Flutter resolved four transitive dependencies to versions newer than the upstream lock (`matcher`, `meta`, `test_api`, and `vector_math`); both lock hashes are recorded in the summary. `apksigner` verified this local APK's v2 signature, which uses the Android Debug certificate. That signer differs from the published release signer and does not establish production signing. REA's separate signature view is structural only and explicitly does not verify signatures ([REA signature report](evidence/rea-inspect-apk-signature-local-baseline-001.json), [apksigner result](evidence/apksigner-verification-local-baseline-001.json)).

This build is a private local baseline, not the published release artifact. No behavior check on this APK, transformed candidate, or comparable BEFORE/AFTER REA result was produced. The report makes no protection claim.
