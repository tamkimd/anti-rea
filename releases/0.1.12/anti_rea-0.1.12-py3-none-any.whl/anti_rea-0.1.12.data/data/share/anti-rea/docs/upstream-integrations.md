# Upstream integrations

The current pins were checked against the named upstream releases and package registries on 2026-11-01. The canonical identities and package hashes are in [`locks/upstreams.json`](../locks/upstreams.json); npm runtime locks are separate under `integrations/`.

## Current adapter registry

`anti-rea registry` emits a versioned JSON catalog for the BLA, REA, and e2e runtimes plus built-in source-map, Flutter Android build/readiness, and WASM compile-probe lanes. It checks each external package lock against the recorded hash and reports the pinned package versions, declared license, supported artifact scope, and status/scope for `probe`, `supports`, `plan`, `execute`, `verify`, `collect`, and `cleanup`. `partial` and `unavailable` entries are explicit; a pin or passing probe does not imply that the operation is generally supported. The Flutter lane builds a release APK or app bundle in the shared private baseline snapshot and hashes its output through the CLI or asynchronous MCP `start_flutter_android_baseline_async` tool. Its CLI/MCP preflight checks Flutter, Android SDK, license, and connected-device readiness without accepting licenses or installing tools; it does not verify app builds, signing, or runtime compatibility. The license field is the upstream declaration, not an independent legal review, and source/package equivalence remains unverified where the pin says so. This catalog does not yet register the other platform engines named in the product plan or provide a common runtime-dispatched adapter interface.

The official REA releases list identifies `rea-agents` 6.8.0 as current and records its release commit. The official tester-army/e2e releases list identifies e2e 0.22.0 and its compatible web/mobile package releases. Keep source commits separate from published package identities; source/package equivalence is not verified. [REA releases](https://github.com/morluto/rea/releases), [tester-army/e2e releases](https://github.com/tester-army/e2e/releases)

## Prepare an isolated runtime

Use the adapters to install each npm lock into a new runtime outside the product source and the user's application. Do not run `npm ci` in `integrations/`:

```sh
python3 scripts/e2e_integration.py bootstrap /absolute/path/to/new-e2e-runtime
python3 /path/to/share/anti-rea/scripts/rea_integration.py bootstrap /absolute/path/to/new-rea-runtime
```

The adapters require the exact upstream Node ranges and disable dependency install scripts. Dependency preparation is not evidence that providers or browser/device lanes work.

## Prepare the required BLA engine

BLA is pinned as an optional, target-selected engine. Its adapter installs only into a new external runtime, disables npm install scripts, and verifies the lock and installed package tree. `probe` and `cli-help` confirm package readiness and the exposed CLI; they do not apply protection or establish behavior equivalence. Do not run BLA setup on the user's harness: it edits harness configuration.

```sh
python3 scripts/bla_integration.py bootstrap /absolute/path/to/new-bla-runtime
python3 scripts/bla_integration.py verify-runtime /absolute/path/to/bla-runtime
python3 scripts/bla_integration.py probe /absolute/path/to/bla-runtime
python3 scripts/bla_integration.py cli-help /absolute/path/to/bla-runtime
python3 scripts/bla_integration.py protect-js /absolute/path/to/bla-runtime /absolute/path/to/input.js /absolute/path/to/new-candidate.js /absolute/path/to/private/protect-report.json --intensity balanced --seed run-identifier
python3 scripts/bla_integration.py verify-js /absolute/path/to/bla-runtime /absolute/path/to/input.js /absolute/path/to/candidate.js /absolute/path/to/private/verify-report.json
```

The shared run executor can invoke this adapter only for a selected, approved plan action whose JavaScript source hash matches the saved baseline. Baseline builds run in a retained private copy, and execution and REA comparison use that saved copy as the original-artifact source. The executor stores the candidate and reports in private Anti-REA state, persists execution and BLA-verification records with IDs on the run, and runs the plan's baseline-bound argv behavior command against paired private source/candidate copies. Copies omit excluded dependency/generated trees and discovered symlinks; build argv paths rooted in the project are redirected into the build copy, but other paths and inherited environment variables can still reach files outside it. Commands run with the user's OS privileges, so this is not an OS sandbox. Incomplete candidates are removed on failure/cancellation while private reports are retained. CLI: `anti-rea execute-plan RUN_ID ACTION_ID STATE --bla-runtime RUNTIME`. MCP `execute_plan` schedules the same operation and returns immediately; poll `get_run` for progress, use `cancel_run` to terminate the active process group, then use `get_report` for linked run records or `get_evidence` for an individual saved record. During normal interpreter shutdown, the MCP server signals active workers, terminates their process groups, and joins the worker threads. Worker state is still process-local and cannot be resumed after a crash or forced termination.

The package pin is `bla-agents` 1.6.3 (MIT); npm integrity and lock hash are in `locks/upstreams.json`. The npm package does not publish a source commit identity, so source/package equivalence remains unverified. `protect-js` accepts one regular JS file up to 1 MiB and writes a new candidate plus private raw report; it refuses in-place and existing-output writes. `verify-js` invokes BLA's own invariant verifier. An optional argv behavior command is captured during BEFORE baseline creation and must match the plan command exactly. The executor runs it against the baseline-matching source and candidate; acceptance authenticates the saved baseline report and requires all three runs to succeed with identical bounded stdout. REA comparison runs on bounded, comparable snapshots and is semantically cross-checked by acceptance; findings and BLA verification still do not prove protection. The adapter uses a wall-clock and output-capture budget, but it is not an operating-system sandbox and cannot cap BLA's transient memory/disk use while the upstream process runs.

## Run the owned e2e fixture

Keep the runtime outside the product and target source trees:

```sh
python3 scripts/e2e_integration.py bootstrap /absolute/path/to/new-e2e-runtime
python3 scripts/e2e_integration.py install-browser /absolute/path/to/new-e2e-runtime --browser chromium
python3 scripts/e2e_integration.py fixture /absolute/path/to/new-e2e-runtime /absolute/path/to/new-e2e-runtime/owned-fixture
python3 scripts/e2e_integration.py run /absolute/path/to/new-e2e-runtime/owned-fixture /absolute/path/to/new-e2e-runtime .e2e/before --stage before
```

When the pinned e2e runtime and another selected upstream runtime require different supported Node patch versions, set `ANTI_REA_E2E_NODE` to the absolute executable recorded by the e2e runtime. The adapter checks that exact version and uses it for e2e and its child processes; REA/BLA continue using PATH Node. Use `fixture --kind pwa` to create the owned PWA fixture (or `web`/`static-spa` for the other owned lanes). Use a fresh output path for every attempt. The adapter verifies pinned package tree identities, validates the full upstream `report-v1` schema, checks run/engine/status fields, and confirms the owned fixture's loopback server stopped. This establishes only the owned fixture's behavior, not a user's application behavior. Smoke evidence is ignored by Git under `evidence/fixtures/e2e/`.

For a baseline-stage browser check, pass `--e2e-runtime RUNTIME` to `anti-rea baseline` (or `e2e_runtime` to MCP `start_baseline`), with optional project-relative `--e2e-config` and `--e2e-test-file`. Set `ANTI_REA_E2E_NODE` if this adapter's exact Node identity differs from the shell's PATH Node. The baseline runner copies discovered inputs and hashed artifacts into a private snapshot, runs the selected browser tests before recommendation, retains the report, and records snapshot/runtime/test identities in the baseline. A failed test prevents baseline creation and retains its report for diagnosis. `recommend ... --e2e-behavior` requires this captured evidence. After approval, the BLA lane reuses the immutable BEFORE report and runs only the candidate snapshot with the same test configuration. The adapter validates report hashes, test scope, and server cleanup. The runner currently requires the fixture-compatible web config shape. Project-supplied config and test code runs with the user's OS privileges in a private copy; this is not an OS sandbox, a general web build adapter, or proof of protection. Discovery excludes dependency/generated directories, so applications requiring those files in the snapshot remain blocked until a verified preparation lane supplies them.

The Python MCP SDK is pinned to 2.3.0 in `pyproject.toml`; a CPython 3.11 macOS ARM64 hash lock is in `locks/pylock.toml`. That lock is platform-specific and uses pip's experimental PEP 751 support; generate and verify a corresponding lock before using another Python/platform combination. [Official Python SDK](https://github.com/modelcontextprotocol/python-sdk), [v2.3.0 release](https://github.com/modelcontextprotocol/python-sdk/releases/tag/v2.3.0)

## Candidate pin review

Prepare a candidate `upstreams.json` and its package-lock files in a separate directory tree, preserving the relative paths declared by the manifest. Run `anti-rea upstream-review /path/to/candidate/locks/upstreams.json` before promotion. The command verifies direct package versions/integrities and lockfile hashes, compares the candidate identities with the checked-in stable pin, and lists the affected regression lanes. A changed candidate remains `review_required` with `promotion: not_authorized`.

After separately installing a candidate and collecting its source/runtime ledger, compare the declared capability names and runtime MCP tool-schema digest:

```sh
anti-rea upstream-capabilities locks/rea-source-runtime-ledger.json /path/to/candidate/source-runtime-ledger.json
```

The comparison reports CLI command, MCP prompt, and MCP tool additions/removals across stable and candidate source/runtime inventories; checks the candidate's declared source commit and runtime package/version/integrity against measured ledger identities; compares source commit and file hashes plus runtime package/version/integrity, lock hash, runtime-manifest hash, and Node version; detects source/runtime name drift; and flags a changed runtime tool-schema digest. It hashes the exact ledger bytes read. Any identity or contract change remains review-required and never authorizes promotion. Name inventories and a schema digest do not explain behavioral differences or prove provider readiness; inspect the candidate contracts, run the affected regression lanes, and review evidence before changing stable pins. Candidate installation and promotion remain explicit manual steps.

Upstream manifest/lock review and REA comparison report/scope readers fail closed when no-follow file opens are unavailable.

Use the REA-specific adapter to create an isolated runtime, verify the installed package tree, and make a version probe. The adapter refuses to install or run when Node is outside the exact pinned engine range:

```sh
python3 scripts/rea_integration.py bootstrap /absolute/path/to/new-rea-runtime
python3 scripts/rea_integration.py verify-runtime /absolute/path/to/rea-runtime
python3 scripts/rea_integration.py probe /absolute/path/to/rea-runtime
python3 scripts/rea_integration.py doctor /absolute/path/to/rea-runtime /absolute/path/to/private/rea-doctor.json
python3 scripts/rea_integration.py mcp-inventory /absolute/path/to/rea-runtime /absolute/path/to/private/rea-tools.json
python3 scripts/rea_integration.py analyze-javascript /absolute/path/to/rea-runtime /absolute/path/to/app /absolute/path/to/private/rea-output.jsonl /absolute/path/to/private/rea-evidence.json
python3 scripts/rea_integration.py compare-javascript /absolute/path/to/rea-runtime /absolute/path/to/before-app /absolute/path/to/after-app /absolute/path/to/private/comparison-evidence
python3 scripts/rea_integration.py mcp-analyze /absolute/path/to/rea-runtime /absolute/path/to/app /absolute/path/to/private/rea-mcp-evidence.json
```

The adapter refuses unsupported Node versions, verifies the installed package tree against its runtime manifest, and saves raw doctor/analysis evidence to new files in existing directories (the adapter does not change their permissions). The doctor summary also returns every upstream check's name, pass state, classification, and remediation while leaving path details in the private raw report. MCP inventory collects runtime tools and prompts; `locks/rea-source-runtime-ledger.json` compares them with the pinned source `TOOL_CONTRACTS` and `PROMPT_CONTRACTS`, and compares the source `CLI_COMMANDS` with the installed runtime's `rea --help`. For REA 6.8.0, all 229 MCP tool names, six guided workflow prompts, and 175 CLI commands match exactly. The separate `locks/rea-capability-readiness.json` ledger pins the source/runtime inventories, the host doctor report, and owned-fixture evidence. It marks JavaScript static analysis `verified_fixture` only for that fixture. Other discovered target families remain Anti-REA `not_supported` with REA applicability `unknown`; provider-to-tool mapping is unknown unless a check is listed. This host doctor snapshot is incomplete: Node and host checks pass, five native-analysis providers are unavailable, and skill identity plus six harness registrations drift. A matching inventory or provider check does not establish protection. `compare-javascript` requires distinct directories, identical relative file scope (symlinks fail closed), identical pinned runtime and summary view, complete equal analysis coverage, and matching relevant/parsed file counts; it retains both raw reports and evidence bundles and hashes the compared path list. The BLA execution path binds this comparison to saved run acceptance; standalone comparisons remain measurements only and do not establish protection. MCP analysis and inventory require the Python 3.11+ package environment and make real stdio calls. The current verified REA runtime is Node 24.22.1. The pinned runtime advertises 229 tools; `locks/rea-runtime-tool-contracts.json.gz` stores their input/output schemas, bound to the package/source identities and exact lock hash. The `locks/rea-capability-inventory.json` file remains a separate inventory of names extracted from the published package bundle. The pinned runtime doctor currently reports missing Hopper/Ghidra/IDA/JADX/Kuna readiness and configuration drift for six harness registrations.

For a BEFORE result available at decision time, pass `--rea-runtime` to `anti-rea baseline` or `rea_runtime` to MCP `start_baseline`. The capture analyzes a private snapshot reconstructed from unchanged discovered inputs and the hash-verified JS artifact. It requires complete summary-view coverage and stores the raw report, bundle, snapshot, and runtime identity in baseline evidence. Resume revalidates these identities. This is a whole-target summary on discovered files, not a reconstruction benchmark.

The owned `fixtures/e2e/static-spa` demonstrates a production-output tree lane: build the app, hash its HTML/JS/CSS artifacts, and capture browser behavior against a private snapshot served by the project’s pinned e2e config. The candidate lane transforms the declared JS file while preserving the other declared output files, then checks the same browser journey and REA snapshot scope. This verifies the fixture contract only; framework support, SSR, full-stack services, and platform build adapters remain unverified.

The owned `fixtures/e2e/pwa` adds a browser fixture for a same-origin service worker: the worker activates, creates a versioned Cache Storage entry, serves a declared resource from cache after the fixture server drops network requests, and transitions from revision 1 to revision 2 while removing its prior cache. This is evidence for this fixture and the pinned Chromium/e2e runtime only. It does not verify cross-browser behavior, production hosting headers, framework integrations, or general PWA support.

Generated BLA JavaScript plans also bind a three-trial local transform budget (`max_elapsed_ms` and `max_candidate_bytes`). When an e2e baseline report includes the owned fixture's browser timing marker, enabling `--e2e-behavior` adds three source and three candidate runs measuring Navigation Timing DOMContentLoaded/load and the greeting interaction. A plan binds the allowed median regression. CLI `recommend` accepts `--performance-max-ms`, `--performance-max-bytes`, and `--performance-max-journey-regression-percent`; MCP `create_plan` accepts the corresponding `performance_max_ms`, `performance_max_bytes`, and `performance_max_journey_regression_percent`. Acceptance authenticates raw e2e reports and recomputes variability summaries and regression. Browser timings are fixture-specific browser observations, not a general application latency benchmark; all timing evidence is machine and browser dependent.

No upstream source tree is cloned automatically. Before running an upstream engine, inspect the selected package's contracts and safety requirements, then record the installed package tree hash and exact runtime identity. Preserve licenses and notices when redistribution applies.
