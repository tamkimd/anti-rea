"""Small command planner for an explicitly selected Flutter Android release build."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

from core import baseline, workflow

_ANDROID_SECTION = re.compile(r"^\[(✓|!|✗)\] Android toolchain(?:\s|$)(.*)$", re.MULTILINE)
_ANDROID_SDK_MISSING = re.compile(r"android sdk (?:was )?not found|unable to locate (?:the )?android sdk", re.I)
_ANDROID_LICENSES_MISSING = re.compile(r"android licenses? (?:are )?not accepted|licenses? not accepted", re.I)
_JAVA_BINARY = re.compile(r"Java binary at:\s*(.+)", re.I)
_JAVA_VERSION = re.compile(r"Java version\s+(.+)", re.I)
_JAVA_MISSING = re.compile(r"(?:unable to locate|could not find|no)\s+(?:a\s+)?java (?:runtime|binary)|java (?:runtime|binary) (?:not found|unavailable)", re.I)
_IDENTITY_TOKEN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+ -]{0,127}$")


def capture_toolchain_identity(command: list[str], cwd: str | Path) -> dict:
    """Capture bounded Flutter/Android/JDK identity for one selected release command."""
    if (not isinstance(command, list) or len(command) < 4 or command[1:4] not in
            (["build", "apk", "--release"], ["build", "appbundle", "--release"])):
        raise workflow.WorkflowError("Flutter toolchain identity requires an explicit Android release command")
    executable = shutil.which(command[0])
    if executable is None:
        raise workflow.WorkflowError("Flutter executable is unavailable while capturing toolchain identity")

    def run(args, timeout):
        try:
            code, stdout, stderr, timed_out, out_limit, err_limit = baseline._run_command(
                [executable, *args], Path(cwd), timeout, total_output_limit=1024 * 1024)
        except OSError as error:
            raise workflow.WorkflowError(f"Could not capture Flutter toolchain identity: {error}") from error
        if code != 0 or timed_out or out_limit or err_limit:
            raise workflow.WorkflowError("Flutter toolchain identity command failed, timed out, or exceeded output limits")
        return (stdout + b"\n" + stderr).decode("utf-8", errors="strict")

    try:
        version = json.loads(run(["--version", "--machine"], 30))
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        raise workflow.WorkflowError("Flutter toolchain version output is invalid") from error
    if not isinstance(version, dict):
        raise workflow.WorkflowError("Flutter toolchain version output is invalid")
    fields = {"framework_version": version.get("frameworkVersion"), "channel": version.get("channel"),
              "framework_revision": version.get("frameworkRevision"),
              "engine_revision": version.get("engineRevision"), "dart_sdk_version": version.get("dartSdkVersion")}
    if any(not isinstance(v, str) or not _IDENTITY_TOKEN.fullmatch(v) for v in fields.values()):
        raise workflow.WorkflowError("Flutter framework, engine, or Dart toolchain identity is incomplete")
    doctor = run(["doctor", "-v", "--suppress-analytics"], 180)
    section_match = _ANDROID_SECTION.search(doctor)
    if not section_match:
        raise workflow.WorkflowError("Flutter doctor did not report the Android toolchain")
    start = section_match.start()
    following = re.search(r"^\[[✓!✗]\] ", doctor[section_match.end():], re.MULTILINE)
    section = doctor[start:section_match.end() + following.start() if following else len(doctor)]
    sdk = re.search(r"Android SDK version ([0-9][A-Za-z0-9._+-]{0,63})", section, re.I)
    platform = re.search(r"Platform (android-[0-9][A-Za-z0-9._+-]{0,63})", section, re.I)
    build_tools = re.search(r"build-tools ([0-9][A-Za-z0-9._+-]{0,63})", section, re.I)
    java_binary = re.search(r"Java binary at:\s*(.+)", section, re.I)
    java_version = re.search(r"Java version\s+(.+)", section, re.I)
    if not all((sdk, platform, build_tools, java_binary, java_version)):
        raise workflow.WorkflowError("Flutter doctor Android SDK, build-tools, or JDK identity is incomplete")
    binary = java_binary.group(1).strip()
    jdk = java_version.group(1).strip()
    if (not Path(binary).is_absolute() or len(binary) > 1024 or len(jdk) > 256
            or any(ord(char) < 32 for char in binary + jdk)):
        raise workflow.WorkflowError("Flutter doctor returned an invalid JDK identity")
    return {"flutter": fields,
            "android": {"sdk_version": sdk.group(1), "platform_version": platform.group(1),
                        "build_tools_version": build_tools.group(1)},
            "java": {"binary": binary, "version": jdk},
            "build": {"target": command[2],
                      "command_sha256": hashlib.sha256(workflow.canonical(command)).hexdigest()}}


def build_command(project: str | Path, target: str, split_debug_info: str | Path | None = None,
                  flutter: str = "flutter", *, obfuscate: bool = False) -> list[str]:
    """Return a Flutter Android release build, with optional Dart obfuscation."""
    root = Path(project).expanduser().resolve(strict=True)
    if not root.is_dir() or not (root / "pubspec.yaml").is_file() or not (root / "android").is_dir():
        raise workflow.WorkflowError("Flutter Android project requires pubspec.yaml and android/ at its root")
    if target not in {"apk", "appbundle"}:
        raise workflow.WorkflowError("Flutter Android target must be apk or appbundle")
    if not isinstance(obfuscate, bool):
        raise workflow.WorkflowError("Flutter obfuscation selection must be a boolean")
    executable = shutil.which(flutter)
    if executable is None:
        raise workflow.WorkflowError(f"Flutter executable is unavailable: {flutter}")
    debug_info = None
    if split_debug_info is not None:
        debug_info = Path(split_debug_info).expanduser().resolve()
        if debug_info == root or root in debug_info.parents:
            raise workflow.WorkflowError("Split debug information must be stored outside the project")
        if not obfuscate:
            raise workflow.WorkflowError("Split debug information requires --obfuscate")
    if obfuscate and debug_info is None:
        raise workflow.WorkflowError("Flutter obfuscation requires a private split-debug-info path")
    command = [executable, "build", target, "--release"]
    if obfuscate:
        command.extend(["--obfuscate", f"--split-debug-info={debug_info}"])
    return command


def probe_android_environment(flutter: str = "flutter", timeout_seconds: float = 120) -> dict:
    """Report Flutter, Android SDK/license/JDK, and device readiness without changing the host."""
    if (isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float))
            or not 0 < timeout_seconds <= 600):
        raise workflow.WorkflowError("Flutter probe timeout must be greater than 0 and at most 600 seconds")
    if not isinstance(flutter, str) or not flutter.strip():
        raise workflow.WorkflowError("Flutter executable must be a non-empty path or command")
    executable = shutil.which(flutter)
    if executable is None:
        return _probe_result(flutter, None, [], "unavailable", None, "unknown", "unknown")

    commands = []

    def run(args, limit):
        argv = [executable, *args]
        try:
            code, stdout, stderr, timed_out, stdout_truncated, stderr_truncated = baseline._run_command(
                argv, Path.cwd(), min(float(timeout_seconds), limit), total_output_limit=1024 * 1024)
        except OSError as error:
            return {"argv": argv, "status": "failed", "error": str(error)}
        record = {"argv": argv, "exit_code": code,
                  "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
                  "stderr_sha256": hashlib.sha256(stderr).hexdigest(),
                  "stdout": stdout.decode("utf-8", errors="replace"),
                  "stderr": stderr.decode("utf-8", errors="replace"),
                  "status": "timed_out" if timed_out else "output_limit" if stdout_truncated or stderr_truncated
                  else "completed" if code == 0 else "failed"}
        commands.append(record)
        return record

    version_result = run(["--version", "--machine"], 30)
    version_data = None
    if version_result["status"] == "completed":
        try:
            value = json.loads(version_result["stdout"])
            if (isinstance(value, dict) and isinstance(value.get("frameworkVersion"), str)
                    and value["frameworkVersion"] and isinstance(value.get("channel"), str)
                    and value["channel"]):
                version_data = {key: value[key] for key in
                                ("frameworkVersion", "channel", "frameworkRevision", "engineRevision", "dartSdkVersion")
                                if isinstance(value.get(key), str)}
        except json.JSONDecodeError:
            pass
    if version_data is None:
        return _probe_result(flutter, executable, commands, "incomplete", None, "unknown", "unknown")

    doctor = run(["doctor", "-v", "--suppress-analytics"], 180)
    doctor_text = doctor.get("stdout", "") + "\n" + doctor.get("stderr", "")
    match = _ANDROID_SECTION.search(doctor_text)
    if not match:
        sdk_status, license_status = "unknown", "unknown"
        java = {"status": "unknown", "binary": None, "version": None}
    else:
        mark, detail = match.groups()
        start, end = match.span()
        next_section = re.search(r"^\[[✓!✗]\] ", doctor_text[end:], re.MULTILINE)
        section = detail + (doctor_text[end:end + next_section.start()] if next_section else doctor_text[end:])
        java_binary = _JAVA_BINARY.search(section)
        java_version = _JAVA_VERSION.search(section)
        binary = java_binary.group(1).strip() if java_binary else ""
        version = java_version.group(1).strip() if java_version else ""
        if _JAVA_MISSING.search(section):
            java = {"status": "missing", "binary": None, "version": None}
        elif (binary and Path(binary).is_absolute() and len(binary) <= 1024
                and version and len(version) <= 256
                and not any(ord(char) < 32 for char in binary + version)):
            java = {"status": "ready", "binary": binary, "version": version}
        else:
            java = {"status": "incomplete", "binary": None, "version": None}
        if _ANDROID_SDK_MISSING.search(section):
            sdk_status, license_status = "blocked", "unknown"
        elif mark == "✓":
            sdk_status, license_status = "ready", "accepted"
        elif _ANDROID_LICENSES_MISSING.search(section):
            sdk_status, license_status = "ready", "not_accepted"
        else:
            sdk_status, license_status = "incomplete", "unknown"
    if doctor["status"] in {"timed_out", "output_limit", "failed"}:
        if sdk_status == "ready":
            sdk_status = "incomplete"
        if license_status == "accepted":
            license_status = "unknown"
        java = {"status": "unknown", "binary": None, "version": None}

    devices_result = run(["devices", "--machine", "--suppress-analytics"], 60)
    devices = None
    if devices_result["status"] == "completed":
        try:
            value = json.loads(devices_result["stdout"])
            if isinstance(value, list) and all(isinstance(item, dict) for item in value):
                android = [item for item in value if isinstance(item.get("targetPlatform"), str)
                           and item["targetPlatform"].startswith("android") and item.get("isSupported") is True]
                devices = {"status": "available" if android else "none_connected",
                           "count": len(android),
                           "emulator_count": sum(item.get("emulator") is True for item in android),
                           "physical_count": sum(item.get("emulator") is False for item in android)}
        except json.JSONDecodeError:
            pass
    devices_result.pop("stdout", None)  # Device IDs can contain stable, user-specific hardware identifiers.
    if devices is None:
        devices = {"status": "unknown", "count": None, "emulator_count": None, "physical_count": None}

    build_status = "ready" if (sdk_status == "ready" and license_status == "accepted"
                                and java["status"] == "ready") else (
        "blocked" if "blocked" in {sdk_status, license_status} or license_status == "not_accepted"
        or java["status"] == "missing"
        else "incomplete")
    device_status = "ready" if devices["status"] == "available" else (
        "blocked" if devices["status"] == "none_connected" else "incomplete")
    status = "ready" if build_status == "ready" and device_status == "ready" else (
        "blocked" if "blocked" in {build_status, device_status} else "incomplete")
    return {"status": status, "scope": "flutter_android_toolchain_only",
            "flutter": {"executable": str(Path(executable).resolve()), **version_data},
            "checks": {"android_sdk": sdk_status, "android_licenses": license_status,
                       "android_java": java, "android_build": build_status, "android_device": devices},
            "commands": commands,
            "limitations": ["Does not build, sign, install, or run an application.",
                            "Does not accept Android licenses or install toolchains.",
                            "Toolchain readiness does not establish app compatibility."]}


def _probe_result(flutter: str, executable: str | None, commands: list[dict], status: str,
                  version: dict | None, sdk_status: str, license_status: str) -> dict:
    return {"status": status, "scope": "flutter_android_toolchain_only",
            "flutter": ({"executable": str(Path(executable).resolve()), **version} if executable and version else None),
            "requested_flutter": flutter,
            "checks": {"android_sdk": sdk_status, "android_licenses": license_status,
                       "android_java": {"status": "unknown", "binary": None, "version": None},
                       "android_build": "incomplete", "android_device": {"status": "unknown", "count": None,
                                                                              "emulator_count": None,
                                                                              "physical_count": None}},
            "commands": commands,
            "limitations": ["Does not build, sign, install, or run an application.",
                            "Does not accept Android licenses or install toolchains.",
                            "Toolchain readiness does not establish app compatibility."]}
