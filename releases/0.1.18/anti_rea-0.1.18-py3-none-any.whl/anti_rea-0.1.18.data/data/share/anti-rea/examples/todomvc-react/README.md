# TodoMVC React example target

This is an Anti-REA verification harness for the maintained React example in [`tastejs/todomvc`](https://github.com/tastejs/todomvc/tree/ff43b02e59dfa604386bb382034b2cd07c2bcd8a/examples/react), pinned at commit `ff43b02e59dfa604386bb382034b2cd07c2bcd8a`. The upstream repository's [`license.md`](https://github.com/tastejs/todomvc/blob/ff43b02e59dfa604386bb382034b2cd07c2bcd8a/license.md) states that repository contents are MIT unless otherwise specified. Keep that license and upstream attributions with any copy. This example does not vendor upstream application code.

The current upstream React example requires Node 20.19+ and npm 10+. Its build is `npm run build` and emits `dist/index.html`, `dist/app.bundle.js`, and `dist/app.css`. Prepare dependencies with the pinned example's `npm ci` before capture. Anti-REA runs the explicit build inside its private source snapshot; generated `node_modules` and `dist` are not used as source inputs.

For an isolated checkout at `/tmp/anti-rea-example-todomvc/examples/react`, copy `e2e.config.mjs` to the checkout root, `tests/behavior.e2e.ts` to its `tests/` directory, and `server.cjs` to `anti-rea-example/server.cjs`. The harness uses the project-relative test layout expected by the pinned runner. Then run:

```sh
npm ci --ignore-scripts --no-audit --no-fund
anti-rea inspect /tmp/anti-rea-example-todomvc/examples/react --store /tmp/anti-rea-todomvc-state
```

Capture the baseline from the checkout root with artifacts `dist/index.html`, `dist/app.bundle.js`, `dist/app.bundle.js.LICENSE.txt`, `dist/app.bundle.js.map`, `dist/app.css`, `dist/app.css.map`, and `dist/base.js`. Put `dist/app.bundle.js` first among artifact arguments so the recorded REA analysis scope is the primary application bundle; support script `base.js` remains in the captured output inventory but is not covered by that single-file REA analysis. Use `--e2e-runtime /path/to/pinned-e2e-runtime --e2e-config e2e.config.mjs --e2e-test-file tests/behavior.e2e.ts --rea-runtime /path/to/pinned-rea-runtime` and build command `sh -c 'npm ci --ignore-scripts --no-audit --no-fund && npm run build'` after `--`.

The acceptance journey checks only blank-input rejection, adding one todo, toggling it complete, and Active/Completed filtering. The selected React example currently stores todos in component state and does not persist them across reloads, so persistence is deliberately outside this check. This is a synthetic third-party target for exercising Anti-REA's web workflow. Its results do not establish protection for the user's application.

## Captured example evidence

On 2026-11-01, Anti-REA built the pinned React target in a private snapshot and passed the browser journey. The detached summary in [`evidence-summary.json`](evidence-summary.json) records the upstream commit, license, package-lock and artifact hashes, runtime identities, test result, and the plan-bound recommendation. The run is still `awaiting_decision`; no candidate was executed. The original whole-snapshot REA analysis timed out after 300 seconds. A targeted retry on the same pinned snapshot and 236,914-byte `dist/app.bundle.js`, using REA 6.8.0, Node 24.22.1, a 2 GiB worker heap, and a 600-second per-source deadline, also timed out. Its sanitized diagnostic record is [`evidence/rea-attempt-600s-targeted.json`](evidence/rea-attempt-600s-targeted.json); it reports zero parsed JavaScript files, one skipped file, and zero findings, so it is not a usable REA baseline. No candidate was executed and no protection claim is supported.
