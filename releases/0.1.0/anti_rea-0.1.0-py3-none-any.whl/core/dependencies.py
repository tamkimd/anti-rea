"""Prepare only the pinned upstream runtimes selected for a workflow."""
from __future__ import annotations

import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import sysconfig

from core import workflow

ROOT = Path(__file__).resolve().parents[1]
_RUNTIME_ENV = {"bla": "ANTI_REA_BLA_RUNTIME", "e2e": "ANTI_REA_E2E_RUNTIME",
                "rea": "ANTI_REA_REA_RUNTIME"}


def _upstreams_path() -> Path:
    path = ROOT / "locks/upstreams.json"
    if path.is_file():
        return path
    path = Path(sysconfig.get_path("data")) / "share/anti-rea/locks/upstreams.json"
    if not path.is_file():
        raise workflow.WorkflowError("Packaged upstream lock file is unavailable")
    return path


def _node_identity(engine: str, adapter):
    checker = adapter.runner if engine == "bla" else adapter
    version, parts = checker.node_version()
    supported = (adapter.supported_node(parts) if engine in {"bla", "rea"}
                 else ((parts[0] == 22 and parts >= (22, 22, 3)) or
                       (parts[0] >= 24 and parts >= (24, 8, 0)))
                 if engine == "e2e" else False)
    if not supported:
        raise workflow.WorkflowError(f"Pinned {engine} runtime does not support Node {version}")
    return version


def _private_directory(path: Path) -> Path:
    if path.is_symlink():
        raise workflow.WorkflowError("Dependency cache directories cannot be symlinks")
    if not path.exists():
        path.mkdir(mode=0o700, parents=True)
    if not path.is_dir():
        raise workflow.WorkflowError("Dependency cache path must be a directory")
    if os.name != "nt":
        info = path.stat()
        if info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise workflow.WorkflowError("Dependency cache directories must be private and owned by the current user")
    return path


def _runtime_identity(engine: str, adapter, runtime: Path, node_version: str):
    try:
        runtime, manifest = adapter.verify_runtime(runtime)
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} runtime verification failed: {error}") from error
    if manifest.get("node_version") != node_version:
        raise workflow.WorkflowError("Pinned runtime was prepared with a different Node version")
    return runtime, manifest


def prepare(engine: str, project: str | Path, cache: str | Path | None, adapter,
            runtime: str | Path | None = None, offline: bool = False) -> dict:
    """Verify an explicit runtime or prepare/reuse an isolated pinned cache entry."""
    if engine not in _RUNTIME_ENV:
        raise workflow.WorkflowError("Unknown upstream engine")
    if not isinstance(offline, bool):
        raise workflow.WorkflowError("Offline mode must be boolean")
    project_root = Path(project).expanduser().resolve(strict=True)
    if not project_root.is_dir():
        raise workflow.WorkflowError("Project root must be a directory")
    pin = json.loads(_upstreams_path().read_text())["integrations"][engine]
    try:
        node_version = _node_identity(engine, adapter)
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} Node runtime is unavailable: {error}") from error
    configured = runtime or os.environ.get(_RUNTIME_ENV[engine])
    if configured:
        selected = Path(configured).expanduser()
        if selected.is_symlink():
            raise workflow.WorkflowError("Configured runtime cannot be a symlink")
        selected, manifest = _runtime_identity(engine, adapter, selected, node_version)
        return _result(engine, pin, selected, manifest, node_version,
                       manifest.get("npm_version_runtime"), "verified", "explicit")

    if cache is None:
        raise workflow.WorkflowError("Pass --cache-dir when no verified runtime was supplied")
    try:
        npm_version = subprocess.run(["npm", "--version"], check=True, capture_output=True,
                                     text=True, timeout=10).stdout.strip()
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} npm runtime is unavailable: {error}") from error

    cache_root = Path(cache).expanduser().absolute()
    if cache_root.is_symlink():
        raise workflow.WorkflowError("Dependency cache cannot be a symlink")
    canonical_cache = cache_root.resolve(strict=False)
    if canonical_cache == project_root or project_root in canonical_cache.parents:
        raise workflow.WorkflowError("Dependency cache must be outside the project")
    if offline and not canonical_cache.is_dir():
        raise workflow.WorkflowError("Offline dependency cache miss; prepare this pinned runtime while online")
    _private_directory(canonical_cache)
    node_key = re.sub(r"[^a-zA-Z0-9._-]", "_", node_version)
    npm_key = re.sub(r"[^a-zA-Z0-9._-]", "_", npm_version)
    platform_key = f"{sys.platform}-{platform.machine().lower()}"
    entry = canonical_cache / engine / f"{pin.get('npm_version', 'multi')}-{platform_key}-node-{node_key}-npm-{npm_key}"
    if entry.exists() or entry.is_symlink():
        if entry.is_symlink():
            raise workflow.WorkflowError("Cached runtime cannot be a symlink")
        selected, manifest = _runtime_identity(engine, adapter, entry, node_version)
        return _result(engine, pin, selected, manifest, node_version, npm_version, "reused", "cache")
    if offline:
        raise workflow.WorkflowError("Offline dependency cache miss; prepare this pinned runtime while online")
    _private_directory(entry.parent)
    try:
        adapter.bootstrap(entry)
    except Exception as error:
        raise workflow.WorkflowError(f"Pinned {engine} runtime preparation failed: {error}") from error
    selected, manifest = _runtime_identity(engine, adapter, entry, node_version)
    return _result(engine, pin, selected, manifest, node_version, npm_version, "prepared", "cache")


def _result(engine: str, pin: dict, runtime: Path, manifest: dict, node_version: str,
            npm_version: str, status: str, source: str) -> dict:
    packages = ({"e2e": pin["packages"]} if engine == "e2e" else
                {pin["npm_package"]: {"version": pin["npm_version"], "integrity": pin["npm_integrity"]}})
    tree_hash = manifest.get("package_tree_sha256")
    return {"status": status, "engine": engine, "runtime": str(runtime), "source": source,
            "packages": packages, "license": pin["license"], "node_requirement": pin["node_requirement"],
            "node_version": node_version, "npm_version": npm_version,
            "package_lock_sha256": pin["package_lock_sha256"],
            "package_tree_sha256": tree_hash,
            "install_scripts": manifest.get("install_scripts", "disabled"),
            "limitations": ["Only the exact pinned runtime is reused; engine applicability and successful operation require separate checks.",
                            "The cache is isolated from the project and does not install global or project dependencies."]}
